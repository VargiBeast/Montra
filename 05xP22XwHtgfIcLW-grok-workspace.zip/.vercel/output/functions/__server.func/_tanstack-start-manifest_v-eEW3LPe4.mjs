//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-eEW3LPe4.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: ["/"],
		preloads: ["/assets/index-CmmEkfNJ.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CmmEkfNJ.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: ["/assets/routes-BqaAnEy6.js"]
	}
} });
//#endregion
export { tsrStartManifest };
