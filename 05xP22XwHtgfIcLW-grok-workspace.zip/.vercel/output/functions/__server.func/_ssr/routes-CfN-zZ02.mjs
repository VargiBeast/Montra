import { b as require_jsx_runtime } from "../_libs/@tanstack/react-router+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CfN-zZ02.js
var import_jsx_runtime = require_jsx_runtime();
var MARK_PATH = "M8 68L8 33.3L32.6 49.2L56 24.1L56 68L64 68L64 3.9L31.4 38.8L0 18.7L0 68Z";
var FACET_PATH = "M64 3.9L55.2 13.2L64 16.5Z";
function signalFill(signal) {
	if (signal === "deep") return "var(--color-copper-deep)";
	if (signal === "copper") return "var(--color-copper)";
	return "none";
}
function Mark({ className, signal = "copper", title }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "-1 0 66 72",
		className,
		role: title ? "img" : void 0,
		"aria-label": title,
		"aria-hidden": title ? void 0 : true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: "currentColor",
			d: MARK_PATH
		}), signal !== "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			fill: signalFill(signal),
			d: FACET_PATH
		}) : null]
	});
}
function Wordmark({ className, signal = "copper", title = "Montra" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
		viewBox: "-2 -2 468 78",
		className,
		role: "img",
		"aria-label": title,
		fill: "none",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: "currentColor",
				d: MARK_PATH
			}),
			signal !== "none" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
				fill: signalFill(signal),
				d: FACET_PATH
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("g", {
				stroke: "currentColor",
				strokeWidth: "8",
				strokeLinecap: "square",
				strokeLinejoin: "round",
				fill: "none",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("circle", {
						cx: "112",
						cy: "36",
						r: "28"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M156 68 V8 L204 68 V8" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M224 8 H280" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M252 8 V68" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M300 68 V8 H332" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M332 8 C356 8 360 22 360 28 C360 42 342 46 324 46 H300" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M320 46 L366 68" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", { d: "M386 68 L424 8 L452 68" }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
						d: "M408 42 H430",
						strokeLinecap: "butt"
					})
				]
			})
		]
	});
}
function AppIcon({ className, tone = "dark", signal }) {
	const resolved = signal ?? (tone === "light" ? "deep" : tone === "mono" ? "none" : "copper");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: `icon-tile ${tone === "light" ? "light text-ink" : tone === "mono" ? "mono" : "text-ivory"} ${className ?? ""}`,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
			signal: resolved,
			className: "h-[62%] w-[62%]"
		})
	});
}
function Glyph({ d }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		viewBox: "0 0 24 24",
		className: "h-1/2 w-1/2 text-ivory/75",
		fill: "none",
		stroke: "currentColor",
		strokeWidth: "1.6",
		"aria-hidden": "true",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d,
			strokeLinejoin: "round",
			strokeLinecap: "round"
		})
	});
}
function Slot({ label, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex min-w-0 flex-col items-center gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "w-full",
			children
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "max-w-full truncate text-xs text-ivory/80",
			children: label
		})]
	});
}
var APPS = [
	{
		label: "Field",
		d: "M5 7h14v10H5z M5 11h14"
	},
	{
		label: "Note",
		d: "M7 5h8l3 3v11H7z M10 12h5 M10 15h4"
	},
	{
		label: "Pulse",
		d: "M3 12h4l2-5 4 10 2-5h6"
	},
	{
		label: "Atlas",
		d: "M12 5a7 7 0 1 0 0 14 7 7 0 0 0 0-14z M5 12h14 M12 5c2 2 2 12 0 14 M12 5c-2 2-2 12 0 14"
	},
	{
		label: "Loom",
		d: "M8 5v14 M16 5v14 M8 12h8"
	},
	{
		label: "North",
		d: "M12 4l6 16H6z"
	},
	{
		label: "Kite",
		d: "M12 4l7 8-7 8-7-8z"
	}
];
function Quiet({ d }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "icon-tile aspect-square w-full opacity-90",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Glyph, { d })
	});
}
function HomeScreen() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "phone",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "phone-screen",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "island" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-5 flex items-center justify-between px-3 text-xs font-medium text-ivory",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: "9:41"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "flex items-center gap-1 text-ivory/80",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 18 12",
							className: "h-3 w-4",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "0",
									y: "7",
									width: "2.2",
									height: "5",
									rx: "0.4",
									fill: "currentColor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "4",
									y: "5",
									width: "2.2",
									height: "7",
									rx: "0.4",
									fill: "currentColor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "8",
									y: "3",
									width: "2.2",
									height: "9",
									rx: "0.4",
									fill: "currentColor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "12",
									y: "1",
									width: "2.2",
									height: "11",
									rx: "0.4",
									fill: "currentColor"
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("svg", {
							viewBox: "0 0 24 12",
							className: "h-3 w-6",
							"aria-hidden": "true",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "0.5",
									y: "0.5",
									width: "20",
									height: "11",
									rx: "2",
									fill: "none",
									stroke: "currentColor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "2",
									y: "2",
									width: "14",
									height: "8",
									rx: "1",
									fill: "currentColor"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("rect", {
									x: "21.5",
									y: "4",
									width: "1.5",
									height: "4",
									rx: "0.4",
									fill: "currentColor"
								})
							]
						})]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-4 gap-x-3 gap-y-4 px-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
						label: "Montra",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { className: "aspect-square w-full" })
					}), APPS.map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
						label: app.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiet, { d: app.d })
					}, app.label))]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "dock",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
						label: "Montra",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { className: "aspect-square w-full" })
					}), APPS.slice(0, 3).map((app) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot, {
						label: app.label,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Quiet, { d: app.d })
					}, `dock-${app.label}`))]
				})
			]
		})
	});
}
var TX = [
	{
		name: "Studio time",
		meta: "Work · Today",
		amount: "−86.00",
		sign: "out"
	},
	{
		name: "Groceries",
		meta: "Home · Today",
		amount: "−54.20",
		sign: "out"
	},
	{
		name: "Client payment",
		meta: "Income · Yesterday",
		amount: "+640.00",
		sign: "in"
	},
	{
		name: "Transit",
		meta: "Move · Yesterday",
		amount: "−18.00",
		sign: "out"
	}
];
function ProductFrame() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "overflow-hidden rounded-xl border border-line bg-ink",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex items-center gap-3 border-b border-line px-4 py-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "h-2 w-2 rounded-full bg-line" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto rounded-full border border-line bg-char px-4 py-1 text-xs text-mist",
					children: "montra.app"
				})
			]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid md:grid-cols-[13rem_1fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("aside", {
				className: "hidden border-r border-line px-4 py-6 md:block",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mb-8 flex items-center gap-2 text-ivory",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
						className: "size-8",
						signal: "copper"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-lg font-semibold tracking-tight",
						children: "Montra"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex flex-col gap-1 text-sm",
					children: [
						"Home",
						"Activity",
						"Wishlist",
						"Goals",
						"More"
					].map((item, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: `rounded-md px-3 py-2 ${i === 0 ? "bg-panel text-ivory" : "text-mist"}`,
						children: item
					}, item))
				})]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-4 py-6 sm:px-6",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mb-6 flex items-center gap-2 md:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, { className: "size-7" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "font-semibold tracking-tight",
							children: "Montra"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "kicker",
						children: "Available"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-4xl font-semibold tracking-tight text-ivory tabular-nums sm:text-5xl",
						children: ["18,420", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "ml-2 text-base font-medium text-mist",
							children: "USD"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-mist",
						children: "This month is on pace. 62% of the plan remains."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "mt-6 grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-line bg-char p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm text-mist",
									children: "Spent"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-2xl font-semibold tabular-nums",
									children: "1,284"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
									viewBox: "0 0 160 42",
									className: "mt-3 h-10 w-full",
									"aria-hidden": "true",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
										d: "M2 30 L18 26 L34 32 L50 18 L66 22 L82 12 L98 16 L114 8 L130 14 L158 6",
										fill: "none",
										stroke: "currentColor",
										strokeWidth: "1.6",
										className: "text-ivory"
									})
								})
							]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "rounded-lg border border-line bg-char p-4",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "flex items-baseline justify-between",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm text-mist",
										children: "Reserve"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "text-sm tabular-nums text-ivory",
										children: "42%"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-2xl font-semibold tabular-nums",
									children: "2,450"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-4 h-1.5 overflow-hidden rounded-full bg-panel",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-full w-[42%] rounded-full bg-copper" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-2 text-xs text-mist",
									children: "of 5,800"
								})
							]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 divide-y divide-line rounded-lg border border-line",
						children: TX.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between gap-3 px-4 py-3",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium",
								children: row.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-mist",
								children: row.meta
							})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium tabular-nums text-ivory",
								children: row.amount
							})]
						}, row.name))
					})
				]
			})]
		})]
	});
}
var NAV = [
	["#primary", "Primary"],
	["#symbol", "Symbol"],
	["#wordmark", "Wordmark"],
	["#icon", "Icon"],
	["#system", "System"],
	["#use", "In use"]
];
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-screen bg-ink text-ivory",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
			className: "sticky top-0 z-20 border-b border-line bg-ink/85 backdrop-blur-md",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 md:px-8",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("a", {
					href: "#primary",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
						className: "size-7",
						title: "Montra"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-semibold tracking-tight",
						children: "Montra"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "ml-auto flex gap-4 overflow-x-auto text-sm text-mist",
					children: NAV.map(([href, label]) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						href,
						className: "shrink-0 py-2 hover:text-ivory",
						children: label
					}, href))
				})]
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
			className: "mx-auto max-w-6xl px-4 pb-24 md:px-8",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "primary",
					className: "scroll-mt-24 py-16 md:py-24",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "01 — Primary logo"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 rounded-xl border border-line bg-char px-6 py-16 md:py-24",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mx-auto flex max-w-xl flex-col items-center text-ivory",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
									className: "w-36 sm:w-44",
									signal: "copper",
									title: "Montra symbol"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
									className: "mt-8 w-full max-w-md",
									signal: "copper"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-5 max-w-xl text-sm leading-relaxed text-mist text-pretty",
							children: "Vertical lockup. The symbol leads, the name follows. One copper facet sits on the higher right peak — the only color in the mark."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "symbol",
					className: "scroll-mt-24 border-t border-line py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "02 — M symbol"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 max-w-xl text-3xl font-semibold tracking-tight text-balance",
							children: "Recognizable without the word."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid items-center gap-8 md:grid-cols-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "flex aspect-square items-center justify-center rounded-xl border border-line bg-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
									className: "w-1/2",
									title: "Montra monogram"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "grid gap-4",
								children: [
									["Shoulder", "The left peak sits lower. The form stays grounded."],
									["Valley", "The center holds the balance. Nothing points, nothing charts."],
									["Peak", "The right stem rises. Progress, cut as geometry — not an arrow."]
								].map(([title, body]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "border-t border-line pt-4",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "text-base font-semibold",
										children: title
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm leading-relaxed text-mist",
										children: body
									})]
								}, title))
							})]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "wordmark",
					className: "scroll-mt-24 border-t border-line py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "03 — Horizontal wordmark"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-semibold tracking-tight",
							children: "MONTRA"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm leading-relaxed text-mist text-pretty",
							children: "Custom letterforms on one stroke weight. Square terminals, a circular O, an asymmetric A that repeats the mark’s rise. Not a typed font."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8 rounded-xl border border-line bg-char px-6 py-12",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, { className: "mx-auto w-full max-w-3xl" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 rounded-xl bg-paper px-6 py-12 text-ink",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
								className: "mx-auto w-full max-w-3xl",
								signal: "deep"
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "icon",
					className: "scroll-mt-24 border-t border-line py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "04 — App icon"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-semibold tracking-tight text-balance",
							children: "Built for a home screen."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm leading-relaxed text-mist",
							children: "One tile, one M. The copper facet stays visible from 64px upward. At 16 and 32 the mark carries the brand alone."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 flex flex-wrap items-end gap-8 rounded-xl border border-line bg-char p-6 md:p-10",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Size, {
									label: "16",
									node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
										className: "px-exact",
										signal: "none"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Size, {
									label: "32",
									node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
										className: "px-exact-32",
										signal: "none"
									})
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Size, {
									label: "64",
									node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { className: "px-exact-64" })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Size, {
									label: "180",
									node: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { className: "px-exact-180" })
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 rounded-xl border border-line bg-ink p-6",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "kicker mb-4",
								children: "512"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, { className: "px-exact-512" })]
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "system",
					className: "scroll-mt-24 border-t border-line py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "05–07 — Dark, light, mono"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-semibold tracking-tight",
							children: "One geometry. Three finishes."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-8 grid gap-3 md:grid-cols-3",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Plate, {
									label: "Dark",
									className: "bg-ink text-ivory",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
										className: "w-24",
										signal: "copper"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
										className: "mt-6 w-full",
										signal: "copper"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Plate, {
									label: "Light",
									className: "bg-paper text-ink",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
										className: "w-24",
										signal: "deep"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
										className: "mt-6 w-full",
										signal: "deep"
									})]
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Plate, {
									label: "Monochrome",
									className: "bg-char text-ivory",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
										className: "w-24",
										signal: "none"
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
										className: "mt-6 w-full",
										signal: "none"
									})]
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker mt-14",
							children: "08 — Small size"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm leading-relaxed text-mist",
							children: "Same path at every size. Below 24px, use the symbol alone. The wordmark is for lockups with room to breathe."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-6 flex items-end gap-6 rounded-xl border border-line bg-paper p-6 text-ink",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
									tone: "light",
									className: "px-exact"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppIcon, {
									tone: "light",
									className: "px-exact-32"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
									signal: "deep",
									className: "h-8 w-8"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mark, {
									signal: "deep",
									className: "h-12 w-12"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Wordmark, {
									signal: "deep",
									className: "hidden h-8 w-auto sm:block"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker mt-14",
							children: "Color"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mt-4 grid grid-cols-2 gap-3 md:grid-cols-5",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									name: "Ink",
									hex: "#0B0C0F",
									className: "bg-ink text-ivory"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									name: "Charcoal",
									hex: "#14171C",
									className: "bg-char text-ivory"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									name: "Ivory",
									hex: "#F4F1EB",
									className: "bg-ivory text-ink"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									name: "Mist",
									hex: "#A39E94",
									className: "bg-mist text-ink"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Swatch, {
									name: "Signal",
									hex: "#D6A57A",
									className: "bg-copper text-ink"
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 max-w-xl text-sm text-mist",
							children: "Signal is used once: the peak facet, and a single progress mark in product. Everything else stays neutral."
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					id: "use",
					className: "scroll-mt-24 border-t border-line py-16",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker",
							children: "09 — iPhone home screen"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "mt-3 text-3xl font-semibold tracking-tight text-balance",
							children: "The M, among quiet tools."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-8",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, {})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "kicker mt-16",
							children: "10 — Product interface"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-3 mb-6 max-w-xl text-sm leading-relaxed text-mist text-pretty",
							children: "Glass-quiet surfaces, ivory type, one copper progress. The symbol sits in the header. Balances use tabular figures."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ProductFrame, {})
					]
				})
			]
		})]
	});
}
function Size({ label, node }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col items-center gap-2",
		children: [node, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "text-xs tabular-nums text-mist",
			children: label
		})]
	});
}
function Plate({ label, className, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `rounded-xl p-6 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "kicker mb-8 opacity-80",
			children: label
		}), children]
	});
}
function Swatch({ name, hex, className }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: `flex min-h-28 flex-col justify-end rounded-lg p-3 ${className}`,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-sm font-semibold",
			children: name
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-xs tabular-nums opacity-80",
			children: hex
		})]
	});
}
//#endregion
export { Home as component };
