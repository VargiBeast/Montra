import type { ReactNode } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { AppIcon, Mark, Wordmark } from "@/components/brand/logo";
import { HomeScreen } from "@/components/brand/phone";
import { ProductFrame } from "@/components/brand/product";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [{ title: "Montra — Brand" }],
  }),
  component: Home,
});

const NAV = [
  ["#primary", "Primary"],
  ["#symbol", "Symbol"],
  ["#wordmark", "Wordmark"],
  ["#icon", "Icon"],
  ["#system", "System"],
  ["#use", "In use"],
];

function Home() {
  return (
    <div className="min-h-screen bg-ink text-ivory">
      <header className="sticky top-0 z-20 border-b border-line bg-ink/85 backdrop-blur-md">
        <div className="mx-auto flex max-w-6xl items-center gap-4 px-4 py-3 md:px-8">
          <a href="#primary" className="flex items-center gap-2">
            <Mark className="size-7" title="Montra" />
            <span className="font-semibold tracking-tight">Montra</span>
          </a>
          <nav className="ml-auto flex items-center gap-4 overflow-x-auto text-sm text-mist">
            {NAV.map(([href, label]) => (
              <a key={href} href={href} className="shrink-0 py-2 hover:text-ivory">
                {label}
              </a>
            ))}
            <a href="/montra-brand.zip" download className="shrink-0 py-2 font-medium text-ivory">
              Download
            </a>
          </nav>
        </div>
      </header>

      <main className="mx-auto max-w-6xl px-4 pb-24 md:px-8">
        <section id="primary" className="scroll-mt-24 py-16 md:py-24">
          <p className="kicker">01 — Primary logo</p>
          <div className="mt-8 rounded-xl border border-line bg-char px-6 py-16 md:py-24">
            <div className="mx-auto flex max-w-xl flex-col items-center text-ivory">
              <Mark className="w-36 sm:w-44" signal="copper" title="Montra symbol" />
              <Wordmark className="mt-8 w-full max-w-md" signal="copper" />
            </div>
          </div>
          <p className="mt-5 max-w-xl text-sm leading-relaxed text-mist text-pretty">
            Vertical lockup. The symbol leads, the name follows. One copper facet sits on the higher right peak — the only color in the mark.
          </p>
        </section>

        <section id="symbol" className="scroll-mt-24 border-t border-line py-16">
          <p className="kicker">02 — M symbol</p>
          <h2 className="mt-3 max-w-xl text-3xl font-semibold tracking-tight text-balance">
            Recognizable without the word.
          </h2>
          <div className="mt-8 grid items-center gap-8 md:grid-cols-2">
            <div className="flex aspect-square items-center justify-center rounded-xl border border-line bg-ink">
              <Mark className="w-1/2" title="Montra monogram" />
            </div>
            <div className="grid gap-4">
              {[
                ["Shoulder", "The left peak sits lower. The form stays grounded."],
                ["Valley", "The center holds the balance. Nothing points, nothing charts."],
                ["Peak", "The right stem rises. Progress, cut as geometry — not an arrow."],
              ].map(([title, body]) => (
                <div key={title} className="border-t border-line pt-4">
                  <h3 className="text-base font-semibold">{title}</h3>
                  <p className="mt-1 text-sm leading-relaxed text-mist">{body}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        <section id="wordmark" className="scroll-mt-24 border-t border-line py-16">
          <p className="kicker">03 — Horizontal wordmark</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight">MONTRA</h2>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-mist text-pretty">
            Custom letterforms on one stroke weight. Square terminals, a circular O, an asymmetric A that repeats the mark’s rise. Not a typed font.
          </p>
          <div className="mt-8 rounded-xl border border-line bg-char px-6 py-12">
            <Wordmark className="mx-auto w-full max-w-3xl" />
          </div>
          <div className="mt-3 rounded-xl bg-paper px-6 py-12 text-ink">
            <Wordmark className="mx-auto w-full max-w-3xl" signal="deep" />
          </div>
        </section>

        <section id="icon" className="scroll-mt-24 border-t border-line py-16">
          <p className="kicker">04 — App icon</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-balance">
            Built for a home screen.
          </h2>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-mist">
            One tile, one M. The copper facet stays visible from 64px upward. At 16 and 32 the mark carries the brand alone.
          </p>
          <div className="mt-8 flex flex-wrap items-end gap-8 rounded-xl border border-line bg-char p-6 md:p-10">
            <Size label="16" node={<AppIcon className="px-exact" signal="none" />} />
            <Size label="32" node={<AppIcon className="px-exact-32" signal="none" />} />
            <Size label="64" node={<AppIcon className="px-exact-64" />} />
            <Size label="180" node={<AppIcon className="px-exact-180" />} />
          </div>
          <div className="mt-4 rounded-xl border border-line bg-ink p-6">
            <p className="kicker mb-4">512</p>
            <AppIcon className="px-exact-512" />
          </div>
        </section>

        <section id="system" className="scroll-mt-24 border-t border-line py-16">
          <p className="kicker">05–07 — Dark, light, mono</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight">One geometry. Three finishes.</h2>
          <div className="mt-8 grid gap-3 md:grid-cols-3">
            <Plate label="Dark" className="bg-ink text-ivory">
              <Mark className="w-24" signal="copper" />
              <Wordmark className="mt-6 w-full" signal="copper" />
            </Plate>
            <Plate label="Light" className="bg-paper text-ink">
              <Mark className="w-24" signal="deep" />
              <Wordmark className="mt-6 w-full" signal="deep" />
            </Plate>
            <Plate label="Monochrome" className="bg-char text-ivory">
              <Mark className="w-24" signal="none" />
              <Wordmark className="mt-6 w-full" signal="none" />
            </Plate>
          </div>

          <p className="kicker mt-14">08 — Small size</p>
          <p className="mt-3 max-w-xl text-sm leading-relaxed text-mist">
            Same path at every size. Below 24px, use the symbol alone. The wordmark is for lockups with room to breathe.
          </p>
          <div className="mt-6 flex items-end gap-6 rounded-xl border border-line bg-paper p-6 text-ink">
            <AppIcon tone="light" className="px-exact" />
            <AppIcon tone="light" className="px-exact-32" />
            <Mark signal="deep" className="h-8 w-8" />
            <Mark signal="deep" className="h-12 w-12" />
            <Wordmark signal="deep" className="hidden h-8 w-auto sm:block" />
          </div>

          <p className="kicker mt-14">Color</p>
          <div className="mt-4 grid grid-cols-2 gap-3 md:grid-cols-5">
            <Swatch name="Ink" hex="#0B0C0F" className="bg-ink text-ivory" />
            <Swatch name="Charcoal" hex="#14171C" className="bg-char text-ivory" />
            <Swatch name="Ivory" hex="#F4F1EB" className="bg-ivory text-ink" />
            <Swatch name="Mist" hex="#A39E94" className="bg-mist text-ink" />
            <Swatch name="Signal" hex="#D6A57A" className="bg-copper text-ink" />
          </div>
          <p className="mt-3 max-w-xl text-sm text-mist">
            Signal is used once: the peak facet, and a single progress mark in product. Everything else stays neutral.
          </p>
        </section>

        <section id="use" className="scroll-mt-24 border-t border-line py-16">
          <p className="kicker">09 — iPhone home screen</p>
          <h2 className="mt-3 text-3xl font-semibold tracking-tight text-balance">The M, among quiet tools.</h2>
          <div className="mt-8">
            <HomeScreen />
          </div>

          <p className="kicker mt-16">10 — Product interface</p>
          <p className="mt-3 mb-6 max-w-xl text-sm leading-relaxed text-mist text-pretty">
            Glass-quiet surfaces, ivory type, one copper progress. The symbol sits in the header. Balances use tabular figures.
          </p>
          <ProductFrame />
        </section>
      </main>
    </div>
  );
}

function Size({ label, node }: { label: string; node: ReactNode }) {
  return (
    <div className="flex flex-col items-center gap-2">
      {node}
      <span className="text-xs tabular-nums text-mist">{label}</span>
    </div>
  );
}

function Plate({
  label,
  className,
  children,
}: {
  label: string;
  className: string;
  children: ReactNode;
}) {
  return (
    <div className={`rounded-xl p-6 ${className}`}>
      <p className="kicker mb-8 opacity-80">{label}</p>
      {children}
    </div>
  );
}

function Swatch({ name, hex, className }: { name: string; hex: string; className: string }) {
  return (
    <div className={`flex min-h-28 flex-col justify-end rounded-lg p-3 ${className}`}>
      <p className="text-sm font-semibold">{name}</p>
      <p className="text-xs tabular-nums opacity-80">{hex}</p>
    </div>
  );
}
