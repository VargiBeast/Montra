export const MARK_PATH =
  "M8 68L8 33.3L32.6 49.2L56 24.1L56 68L64 68L64 3.9L31.4 38.8L0 18.7L0 68Z";

export const FACET_PATH = "M64 3.9L55.2 13.2L64 16.5Z";

type Signal = "copper" | "deep" | "none";

function signalFill(signal: Signal) {
  if (signal === "deep") return "var(--color-copper-deep)";
  if (signal === "copper") return "var(--color-copper)";
  return "none";
}

export function Mark({
  className,
  signal = "copper",
  title,
}: {
  className?: string;
  signal?: Signal;
  title?: string;
}) {
  return (
    <svg
      viewBox="-1 0 66 72"
      className={className}
      role={title ? "img" : undefined}
      aria-label={title}
      aria-hidden={title ? undefined : true}
    >
      <path fill="currentColor" d={MARK_PATH} />
      {signal !== "none" ? <path fill={signalFill(signal)} d={FACET_PATH} /> : null}
    </svg>
  );
}

export function Wordmark({
  className,
  signal = "copper",
  title = "Montra",
}: {
  className?: string;
  signal?: Signal;
  title?: string;
}) {
  return (
    <svg
      viewBox="-2 -2 468 78"
      className={className}
      role="img"
      aria-label={title}
      fill="none"
    >
      <path fill="currentColor" d={MARK_PATH} />
      {signal !== "none" ? <path fill={signalFill(signal)} d={FACET_PATH} /> : null}
      <g
        stroke="currentColor"
        strokeWidth="8"
        strokeLinecap="square"
        strokeLinejoin="round"
        fill="none"
      >
        <circle cx="112" cy="36" r="28" />
        <path d="M156 68 V8 L204 68 V8" />
        <path d="M224 8 H280" />
        <path d="M252 8 V68" />
        <path d="M300 68 V8 H332" />
        <path d="M332 8 C356 8 360 22 360 28 C360 42 342 46 324 46 H300" />
        <path d="M320 46 L366 68" />
        <path d="M386 68 L424 8 L452 68" />
        <path d="M408 42 H430" strokeLinecap="butt" />
      </g>
    </svg>
  );
}

export function AppIcon({
  className,
  tone = "dark",
  signal,
}: {
  className?: string;
  tone?: "dark" | "light" | "mono";
  signal?: Signal;
}) {
  const resolved = signal ?? (tone === "light" ? "deep" : tone === "mono" ? "none" : "copper");
  const toneClass = tone === "light" ? "light text-ink" : tone === "mono" ? "mono" : "text-ivory";
  return (
    <div className={`icon-tile ${toneClass} ${className ?? ""}`}>
      <Mark signal={resolved} className="h-[62%] w-[62%]" />
    </div>
  );
}
