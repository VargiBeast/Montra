import type { ReactNode } from "react";
import { AppIcon } from "./logo";

function Glyph({ d }: { d: string }) {
  return (
    <svg viewBox="0 0 24 24" className="h-1/2 w-1/2 text-ivory/75" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true">
      <path d={d} strokeLinejoin="round" strokeLinecap="round" />
    </svg>
  );
}

function Slot({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex min-w-0 flex-col items-center gap-1">
      <div className="w-full">{children}</div>
      <span className="max-w-full truncate text-xs text-ivory/80">{label}</span>
    </div>
  );
}

const APPS: { label: string; d: string }[] = [
  { label: "Field", d: "M5 7h14v10H5z M5 11h14" },
  { label: "Note", d: "M7 5h8l3 3v11H7z M10 12h5 M10 15h4" },
  { label: "Pulse", d: "M3 12h4l2-5 4 10 2-5h6" },
  { label: "Atlas", d: "M12 5a7 7 0 1 0 0 14 7 7 0 0 0 0-14z M5 12h14 M12 5c2 2 2 12 0 14 M12 5c-2 2-2 12 0 14" },
  { label: "Loom", d: "M8 5v14 M16 5v14 M8 12h8" },
  { label: "North", d: "M12 4l6 16H6z" },
  { label: "Kite", d: "M12 4l7 8-7 8-7-8z" },
];

function Quiet({ d }: { d: string }) {
  return (
    <div className="icon-tile aspect-square w-full opacity-90">
      <Glyph d={d} />
    </div>
  );
}

export function HomeScreen() {
  return (
    <div className="phone">
      <div className="phone-screen">
        <div className="island" />
        <div className="mb-5 flex items-center justify-between px-3 text-xs font-medium text-ivory">
          <span className="tabular-nums">9:41</span>
          <span className="flex items-center gap-1 text-ivory/80">
            <svg viewBox="0 0 18 12" className="h-3 w-4" aria-hidden="true">
              <rect x="0" y="7" width="2.2" height="5" rx="0.4" fill="currentColor" />
              <rect x="4" y="5" width="2.2" height="7" rx="0.4" fill="currentColor" />
              <rect x="8" y="3" width="2.2" height="9" rx="0.4" fill="currentColor" />
              <rect x="12" y="1" width="2.2" height="11" rx="0.4" fill="currentColor" />
            </svg>
            <svg viewBox="0 0 24 12" className="h-3 w-6" aria-hidden="true">
              <rect x="0.5" y="0.5" width="20" height="11" rx="2" fill="none" stroke="currentColor" />
              <rect x="2" y="2" width="14" height="8" rx="1" fill="currentColor" />
              <rect x="21.5" y="4" width="1.5" height="4" rx="0.4" fill="currentColor" />
            </svg>
          </span>
        </div>
        <div className="grid grid-cols-4 gap-x-3 gap-y-4 px-1">
          <Slot label="Montra">
            <AppIcon className="aspect-square w-full" />
          </Slot>
          {APPS.map((app) => (
            <Slot key={app.label} label={app.label}>
              <Quiet d={app.d} />
            </Slot>
          ))}
        </div>
        <div className="dock">
          <Slot label="Montra">
            <AppIcon className="aspect-square w-full" />
          </Slot>
          {APPS.slice(0, 3).map((app) => (
            <Slot key={`dock-${app.label}`} label={app.label}>
              <Quiet d={app.d} />
            </Slot>
          ))}
        </div>
      </div>
    </div>
  );
}
