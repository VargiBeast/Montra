import { Mark } from "./logo";

const TX = [
  { name: "Studio time", meta: "Work · Today", amount: "−86.00", sign: "out" },
  { name: "Groceries", meta: "Home · Today", amount: "−54.20", sign: "out" },
  { name: "Client payment", meta: "Income · Yesterday", amount: "+640.00", sign: "in" },
  { name: "Transit", meta: "Move · Yesterday", amount: "−18.00", sign: "out" },
];

export function ProductFrame() {
  return (
    <div className="overflow-hidden rounded-xl border border-line bg-ink">
      <div className="flex items-center gap-3 border-b border-line px-4 py-3">
        <span className="h-2 w-2 rounded-full bg-line" />
        <span className="h-2 w-2 rounded-full bg-line" />
        <span className="h-2 w-2 rounded-full bg-line" />
        <div className="mx-auto rounded-full border border-line bg-char px-4 py-1 text-xs text-mist">
          montra.app
        </div>
      </div>
      <div className="grid md:grid-cols-[13rem_1fr]">
        <aside className="hidden border-r border-line px-4 py-6 md:block">
          <div className="mb-8 flex items-center gap-2 text-ivory">
            <Mark className="size-8" signal="copper" />
            <span className="text-lg font-semibold tracking-tight">Montra</span>
          </div>
          <nav className="flex flex-col gap-1 text-sm">
            {["Home", "Activity", "Wishlist", "Goals", "More"].map((item, i) => (
              <div
                key={item}
                className={`rounded-md px-3 py-2 ${i === 0 ? "bg-panel text-ivory" : "text-mist"}`}
              >
                {item}
              </div>
            ))}
          </nav>
        </aside>
        <div className="px-4 py-6 sm:px-6">
          <div className="mb-6 flex items-center gap-2 md:hidden">
            <Mark className="size-7" />
            <span className="font-semibold tracking-tight">Montra</span>
          </div>
          <p className="kicker">Available</p>
          <p className="mt-2 text-4xl font-semibold tracking-tight text-ivory tabular-nums sm:text-5xl">
            18,420
            <span className="ml-2 text-base font-medium text-mist">USD</span>
          </p>
          <p className="mt-2 text-sm text-mist">This month is on pace. 62% of the plan remains.</p>
          <div className="mt-6 grid gap-3 sm:grid-cols-2">
            <div className="rounded-lg border border-line bg-char p-4">
              <p className="text-sm text-mist">Spent</p>
              <p className="mt-1 text-2xl font-semibold tabular-nums">1,284</p>
              <svg viewBox="0 0 160 42" className="mt-3 h-10 w-full" aria-hidden="true">
                <path
                  d="M2 30 L18 26 L34 32 L50 18 L66 22 L82 12 L98 16 L114 8 L130 14 L158 6"
                  fill="none"
                  stroke="currentColor"
                  strokeWidth="1.6"
                  className="text-ivory"
                />
              </svg>
            </div>
            <div className="rounded-lg border border-line bg-char p-4">
              <div className="flex items-baseline justify-between">
                <p className="text-sm text-mist">Reserve</p>
                <p className="text-sm tabular-nums text-ivory">42%</p>
              </div>
              <p className="mt-1 text-2xl font-semibold tabular-nums">2,450</p>
              <div className="mt-4 h-1.5 overflow-hidden rounded-full bg-panel">
                <div className="h-full w-[42%] rounded-full bg-copper" />
              </div>
              <p className="mt-2 text-xs text-mist">of 5,800</p>
            </div>
          </div>
          <ul className="mt-4 divide-y divide-line rounded-lg border border-line">
            {TX.map((row) => (
              <li key={row.name} className="flex items-center justify-between gap-3 px-4 py-3">
                <div>
                  <p className="text-sm font-medium">{row.name}</p>
                  <p className="text-xs text-mist">{row.meta}</p>
                </div>
                <p className="text-sm font-medium tabular-nums text-ivory">
                  {row.amount}
                </p>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
