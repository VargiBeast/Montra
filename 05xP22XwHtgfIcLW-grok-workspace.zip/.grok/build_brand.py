#!/usr/bin/env python3
"""Build MONTRA's geometric mark, favicon, and 1200×630 share card."""
import math
from pathlib import Path

INK = "#0B0C0F"
CHARCOAL = "#14171C"
IVORY = "#F4F1EB"
MIST = "#A39E94"
COPPER = "#D6A57A"

# Centerline of the M. Stems are vertical. Left peak is lower (larger y),
# valley x is the midpoint of the stems, right peak is higher (smaller y).
PTS = [
    (0.0, 180.0),
    (0.0, 64.0),
    (86.0, 124.0),
    (172.0, 10.0),
    (172.0, 180.0),
]
HALF = 17.5
# Cut this far along the two edges that meet at the outer right peak.
FACET = 34.0


def sub(a, b):
    return (a[0] - b[0], a[1] - b[1])


def add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def mul(a, s):
    return (a[0] * s, a[1] * s)


def length(a):
    return math.hypot(a[0], a[1])


def norm(a):
    L = length(a)
    return (a[0] / L, a[1] / L)


def perp(a):
    return (-a[1], a[0])


def intersect(p1, d1, p2, d2):
    cross = d1[0] * d2[1] - d1[1] * d2[0]
    if abs(cross) < 1e-9:
        return p1
    rhs = sub(p2, p1)
    t = (rhs[0] * d2[1] - rhs[1] * d2[0]) / cross
    return add(p1, mul(d1, t))


def offset_open(pts, dist):
    n = len(pts)
    dirs = []
    normals = []
    for i in range(n - 1):
        d = norm(sub(pts[i + 1], pts[i]))
        dirs.append(d)
        normals.append(perp(d))

    left = [add(pts[0], mul(normals[0], dist))]
    right = [add(pts[0], mul(normals[0], -dist))]
    for i in range(1, n - 1):
        pL1 = add(pts[i], mul(normals[i - 1], dist))
        pL2 = add(pts[i], mul(normals[i], dist))
        left.append(intersect(pL1, dirs[i - 1], pL2, dirs[i]))
        pR1 = add(pts[i], mul(normals[i - 1], -dist))
        pR2 = add(pts[i], mul(normals[i], -dist))
        right.append(intersect(pR1, dirs[i - 1], pR2, dirs[i]))
    left.append(add(pts[-1], mul(normals[-1], dist)))
    right.append(add(pts[-1], mul(normals[-1], -dist)))
    return left + list(reversed(right))


def along(a, b, dist):
    d = sub(b, a)
    L = length(d)
    if L < 1e-9:
        return a
    t = min(dist, L * 0.42) / L
    return add(a, mul(d, t))


def cut_facet(poly, tip_index, dist):
    n = len(poly)
    prev_i = (tip_index - 1) % n
    next_i = (tip_index + 1) % n
    tip = poly[tip_index]
    p1 = along(tip, poly[prev_i], dist)
    p2 = along(tip, poly[next_i], dist)
    body = poly[:tip_index] + [p1, p2] + poly[tip_index + 1 :]
    facet = [tip, p2, p1]
    return body, facet


def bbox(poly):
    xs = [p[0] for p in poly]
    ys = [p[1] for p in poly]
    return min(xs), min(ys), max(xs), max(ys)


def fmt(poly):
    return " ".join(f"{x:.2f},{y:.2f}" for x, y in poly)


def translate(poly, dx, dy):
    return [(x + dx, y + dy) for x, y in poly]


def scale_about(poly, origin, s):
    ox, oy = origin
    return [((x - ox) * s + ox, (y - oy) * s + oy) for x, y in poly]


def fit_group(polys, box):
    """Uniform-scale a list of polygons into (x, y, w, h), centered."""
    x, y, w, h = box
    points = [p for poly in polys for p in poly]
    minx, miny, maxx, maxy = bbox(points)
    bw = maxx - minx
    bh = maxy - miny
    s = min(w / bw, h / bh)
    out = []
    for poly in polys:
        placed = []
        for px, py in poly:
            nx = x + (w - bw * s) / 2 + (px - minx) * s
            ny = y + (h - bh * s) / 2 + (py - miny) * s
            placed.append((nx, ny))
        out.append(placed)
    return out


poly = offset_open(PTS, HALF)
# Outer right peak is the highest vertex on the right half of the mark.
cx = (PTS[0][0] + PTS[-1][0]) / 2
candidates = [
    i
    for i, (x, y) in enumerate(poly)
    if x > cx
]
tip = min(candidates, key=lambda i: (poly[i][1], -poly[i][0]))
body, facet = cut_facet(poly, tip, FACET)

# Sanity: left peak outer y must be greater (lower on screen) than right peak.
left_candidates = [i for i, (x, y) in enumerate(poly) if x < cx]
left_tip = min(left_candidates, key=lambda i: poly[i][1])
valley_candidates = [i for i, (x, y) in enumerate(poly) if abs(x - cx) < 30]
valley_tip = max(valley_candidates, key=lambda i: poly[i][1])
print("left peak", poly[left_tip], "right peak", poly[tip], "valley", poly[valley_tip])
assert poly[left_tip][1] > poly[tip][1] + 20, "left peak must sit clearly lower"
assert poly[valley_tip][1] > poly[left_tip][1] + 10, "valley must sit below both peaks"

# --- favicon ---
fb, ff = fit_group([body, facet], (4.2, 3.4, 23.6, 25.2))
favicon = f'''<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 32 32">
  <rect width="32" height="32" rx="7" fill="{INK}"/>
  <polygon points="{fmt(fb)}" fill="{IVORY}"/>
  <polygon points="{fmt(ff)}" fill="{COPPER}"/>
</svg>
'''
Path("/workspace/.grok/favicon.svg").write_text(favicon)

# --- share card ---
# Charcoal slab, mark fitted inside it, wordmark below on ink.
slab = (400, 78, 400, 348)
mb, mf = fit_group([body, facet], (slab[0] + 78, slab[1] + 58, slab[2] - 156, slab[3] - 116))

card = f'''<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8"/>
<style>
@font-face {{
  font-family: "Inter";
  src: url("file:///workspace/artifacts/fonts/Inter-Medium.otf") format("opentype");
  font-weight: 500;
  font-style: normal;
}}
html, body {{
  margin: 0;
  padding: 0;
  width: 1200px;
  height: 630px;
  background: {INK};
  overflow: hidden;
}}
svg {{ display: block; }}
</style>
</head>
<body>
<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="630" viewBox="0 0 1200 630">
  <rect width="1200" height="630" fill="{INK}"/>
  <rect x="{slab[0]}" y="{slab[1]}" width="{slab[2]}" height="{slab[3]}" fill="{CHARCOAL}"/>
  <polygon points="{fmt(mb)}" fill="{IVORY}"/>
  <polygon points="{fmt(mf)}" fill="{COPPER}"/>
  <rect x="564" y="458" width="72" height="2" fill="{MIST}"/>
  <text x="600" y="548" text-anchor="middle"
    font-family="Inter, 'Liberation Sans', sans-serif"
    font-weight="500" font-size="72" letter-spacing="16"
    fill="{IVORY}">MONTRA</text>
</svg>
</body>
</html>
'''
Path("/workspace/.grok/og-card.html").write_text(card)
print("wrote favicon + card html")
print("facet bbox", bbox(facet))
print("body bbox", bbox(body))
