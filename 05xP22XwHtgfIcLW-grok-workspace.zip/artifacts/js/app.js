const MARK = `<svg viewBox="0 0 32 32" width="28" height="28" aria-hidden="true"><path fill="currentColor" d="M6.2 24.2V9.4l1.7-1.1 6.7 8.2c.5.6 1.3.6 1.8 0L23 8.2l1.8 1.1v14.9h-3.2v-9.4l-4.7 5.6c-.7.8-1.9.8-2.6 0L9.4 14.8v9.4H6.2Z"/><path fill="#7DCFB8" d="M21.6 10.6 23 8.2l1.8 1.1v3.2l-3.2-1.9Z"/></svg>`;

const I18N = {
  en: {
    "nav.home": "Home", "nav.activity": "Activity", "nav.wishlist": "Wishlist", "nav.goals": "Goals", "nav.more": "More",
    greeting: "Good evening", clarity: "Available to spend", month: "This month", spent: "Spent", left: "Remaining",
    pace: "On pace", recent: "Recent", seeAll: "See all", goals: "Goals", wishlist: "Wishlist",
    add: "Add", purchase: "Purchase", income: "Income", wish: "Wish", goal: "Goal",
    search: "Search activity", all: "All", spending: "Spending", incomeTab: "Income",
    emptyActivity: "Nothing here yet", emptyWish: "Your wishlist is clear", emptyGoals: "No goals yet",
    saved: "saved", of: "of", priority: "Priority", appearance: "Appearance", dark: "Dark", light: "Light",
    currency: "Currency", language: "Language", about: "About Montra",
    aboutBody: "Money clarity without the spreadsheet. Track what you spend, what you want, and what you are building toward.",
    brand: "Mark system", addTitle: "Add to Montra", name: "Name", amount: "Amount", category: "Category",
    save: "Save", cancel: "Cancel", confirm: "Saved", delete: "Remove", target: "Target", note: "Note",
    monthNames: ["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
  },
  no: {
    "nav.home": "Hjem", "nav.activity": "Aktivitet", "nav.wishlist": "Ønskeliste", "nav.goals": "Mål", "nav.more": "Mer",
    greeting: "God kveld", clarity: "Tilgjengelig", month: "Denne måneden", spent: "Brukt", left: "Igjen",
    pace: "I rute", recent: "Siste", seeAll: "Se alle", goals: "Mål", wishlist: "Ønskeliste",
    add: "Legg til", purchase: "Kjøp", income: "Inntekt", wish: "Ønske", goal: "Mål",
    search: "Søk i aktivitet", all: "Alle", spending: "Forbruk", incomeTab: "Inntekt",
    emptyActivity: "Ingenting her ennå", emptyWish: "Ønskelisten er tom", emptyGoals: "Ingen mål ennå",
    saved: "spart", of: "av", priority: "Prioritet", appearance: "Utseende", dark: "Mørk", light: "Lys",
    currency: "Valuta", language: "Språk", about: "Om Montra",
    aboutBody: "Penger med klarhet, uten regneark. Følg det du bruker, det du vil ha, og det du bygger mot.",
    brand: "Merke", addTitle: "Legg til i Montra", name: "Navn", amount: "Beløp", category: "Kategori",
    save: "Lagre", cancel: "Avbryt", confirm: "Lagret", delete: "Fjern", target: "Målbeløp", note: "Notat",
    monthNames: ["jan","feb","mar","apr","mai","jun","jul","aug","sep","okt","nov","des"]
  }
};

const RATES = { USD: 1, EUR: 0.92, GBP: 0.78, NOK: 10.6, SEK: 10.4 };
const SYMBOL = { USD: "$", EUR: "€", GBP: "£", NOK: "kr", SEK: "kr" };

const seed = {
  theme: "dark",
  lang: "en",
  currency: "USD",
  budget: 2400,
  txs: [
    { id: 1, name: "Studio time", cat: "Work", amount: -86, day: "Today" },
    { id: 2, name: "Groceries", cat: "Home", amount: -54.2, day: "Today" },
    { id: 3, name: "Client payment", cat: "Income", amount: 640, day: "Yesterday" },
    { id: 4, name: "Transit", cat: "Move", amount: -18, day: "Yesterday" },
    { id: 5, name: "Headphones", cat: "Gear", amount: -129, day: "Mon" },
    { id: 6, name: "Coffee", cat: "Daily", amount: -6.4, day: "Mon" }
  ],
  wishes: [
    { id: 1, name: "Travel lens", price: 480, saved: 190, priority: "High" },
    { id: 2, name: "Quiet keyboard", price: 160, saved: 40, priority: "Medium" },
    { id: 3, name: "Weekend in Lisbon", price: 720, saved: 260, priority: "Later" }
  ],
  goals: [
    { id: 1, name: "Move fund", target: 8000, saved: 2450, note: "City change" },
    { id: 2, name: "Release budget", target: 1200, saved: 860, note: "Next single" },
    { id: 3, name: "Emergency", target: 3000, saved: 1100, note: "Three months" }
  ],
  series: [42, 55, 38, 70, 48, 62, 44, 80, 58, 66, 52, 74]
};

let state = load();

function load() {
  try {
    const raw = localStorage.getItem("montra");
    if (!raw) return structuredClone(seed);
    return { ...structuredClone(seed), ...JSON.parse(raw) };
  } catch { return structuredClone(seed); }
}
function persist() { localStorage.setItem("montra", JSON.stringify(state)); }
function t(key) { return (I18N[state.lang] || I18N.en)[key] || key; }

function money(usd) {
  const v = usd * RATES[state.currency];
  const abs = Math.abs(v);
  const sym = SYMBOL[state.currency];
  const num = abs.toLocaleString(state.lang === "no" ? "nb-NO" : "en-US", { minimumFractionDigits: abs < 100 ? 2 : 0, maximumFractionDigits: 2 });
  const formatted = state.currency === "NOK" || state.currency === "SEK" ? `${num} ${sym}` : `${sym}${num}`;
  return usd < 0 ? `−${formatted}` : formatted;
}

function spentMonth() {
  return state.txs.filter(x => x.amount < 0).reduce((s, x) => s + Math.abs(x.amount), 0);
}
function incomeMonth() {
  return state.txs.filter(x => x.amount > 0).reduce((s, x) => s + x.amount, 0);
}

function chartSvg() {
  const vals = state.series;
  const max = Math.max(...vals);
  const w = 320, h = 92, p = 6;
  const step = (w - p * 2) / (vals.length - 1);
  const pts = vals.map((v, i) => [p + i * step, h - p - (v / max) * (h - p * 2)]);
  const d = pts.map((p, i) => `${i ? "L" : "M"}${p[0].toFixed(1)},${p[1].toFixed(1)}`).join(" ");
  const fill = `${d} L${pts.at(-1)[0]},${h} L${pts[0][0]},${h} Z`;
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><path d="${fill}" fill="var(--chart-2)"/><path d="${d}" fill="none" stroke="var(--chart)" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>`;
}

function render() {
  document.documentElement.dataset.theme = state.theme;
  document.querySelector('meta[name="theme-color"]').setAttribute("content", state.theme === "light" ? "#F5F3EF" : "#090B10");
  document.querySelectorAll("[data-i]").forEach(el => { el.textContent = t(el.dataset.i); });
  document.getElementById("headerMark").innerHTML = MARK;
  document.getElementById("launchMark").innerHTML = MARK;
  renderHome();
  renderActivity();
  renderWishlist();
  renderGoals();
  renderMore();
}

function renderHome() {
  const spent = spentMonth();
  const left = Math.max(state.budget - spent, 0);
  const el = document.getElementById("screen-home");
  el.innerHTML = `
    <p class="kicker">${t("greeting")}</p>
    <h1>${t("clarity")}</h1>
    <div class="glass hero">
      <div class="balance">${money(left)} <small>${state.currency}</small></div>
      <div class="delta">${t("pace")} · ${Math.round((1 - spent / state.budget) * 100)}%</div>
      <div class="chart">${chartSvg()}</div>
    </div>
    <div class="metrics">
      <div class="card metric"><div class="faint">${t("spent")}</div><div class="num">${money(spent)}</div></div>
      <div class="card metric"><div class="faint">${t("left")}</div><div class="num">${money(left)}</div></div>
    </div>
    <div class="section-head row"><h2>${t("goals")}</h2><button class="chip" data-go="goals">${t("seeAll")}</button></div>
    <div class="card list">${state.goals.slice(0, 2).map(goalRow).join("")}</div>
    <div class="section-head row"><h2>${t("recent")}</h2><button class="chip" data-go="activity">${t("seeAll")}</button></div>
    <div class="card list">${state.txs.slice(0, 4).map(txRow).join("")}</div>
  `;
}

function txRow(tx) {
  const sign = tx.amount < 0 ? "neg" : "pos";
  return `<div class="tx"><div class="avatar">${tx.cat.slice(0, 2).toUpperCase()}</div><div class="meta"><strong>${tx.name}</strong><span class="faint">${tx.cat} · ${tx.day}</span></div><div class="amount ${sign}">${money(tx.amount)}</div></div>`;
}
function goalRow(g) {
  const pct = Math.min(100, Math.round((g.saved / g.target) * 100));
  return `<div class="goal"><div class="meta"><strong>${g.name}</strong><span class="faint">${money(g.saved)} ${t("of")} ${money(g.target)}</span><div class="bar"><span style="width:${pct}%"></span></div></div><div class="badge">${pct}%</div></div>`;
}
function wishRow(w) {
  const pct = Math.min(100, Math.round((w.saved / w.price) * 100));
  return `<div class="wish"><div class="meta"><strong>${w.name}</strong><span class="faint">${money(w.saved)} ${t("saved")} · ${money(w.price)}</span><div class="bar"><span style="width:${pct}%"></span></div></div><span class="badge ${w.priority === "High" ? "warn" : "neutral"}">${w.priority}</span></div>`;
}

function renderActivity() {
  const q = (state.query || "").toLowerCase();
  const f = state.filter || "all";
  let rows = state.txs.filter(tx => {
    if (f === "spending" && tx.amount >= 0) return false;
    if (f === "income" && tx.amount <= 0) return false;
    if (q && !`${tx.name} ${tx.cat}`.toLowerCase().includes(q)) return false;
    return true;
  });
  document.getElementById("screen-activity").innerHTML = `
    <p class="kicker">${t("month")}</p>
    <h1>${t("nav.activity")}</h1>
    <div class="search"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><circle cx="11" cy="11" r="6"/><path d="m16 16 4 4"/></svg><input id="q" placeholder="${t("search")}" value="${state.query || ""}" /></div>
    <div class="seg" style="margin-bottom:12px">
      <button data-filter="all" class="${f === "all" ? "on" : ""}">${t("all")}</button>
      <button data-filter="spending" class="${f === "spending" ? "on" : ""}">${t("spending")}</button>
      <button data-filter="income" class="${f === "income" ? "on" : ""}">${t("incomeTab")}</button>
    </div>
    ${rows.length ? `<div class="card list">${rows.map(txRow).join("")}</div>` : `<div class="card empty"><div class="state-mark">${MARK}</div><strong>${t("emptyActivity")}</strong></div>`}
  `;
  const input = document.getElementById("q");
  if (input) input.addEventListener("input", e => { state.query = e.target.value; persist(); renderActivity(); document.getElementById("q").focus(); });
}

function renderWishlist() {
  document.getElementById("screen-wishlist").innerHTML = `
    <p class="kicker">${state.wishes.length} items</p>
    <h1>${t("wishlist")}</h1>
    <div class="stack" style="margin-top:14px">
      ${state.wishes.length ? state.wishes.map(w => `<article class="card">${wishRow(w)}</article>`).join("") : `<div class="card empty"><strong>${t("emptyWish")}</strong></div>`}
    </div>
  `;
}
function renderGoals() {
  document.getElementById("screen-goals").innerHTML = `
    <p class="kicker">${t("pace")}</p>
    <h1>${t("goals")}</h1>
    <div class="stack" style="margin-top:14px">
      ${state.goals.map(g => `<article class="card">${goalRow(g)}<p class="faint" style="margin:8px 0 0">${g.note}</p></article>`).join("") || `<div class="card empty"><strong>${t("emptyGoals")}</strong></div>`}
    </div>
  `;
}
function renderMore() {
  document.getElementById("screen-more").innerHTML = `
    <p class="kicker">Montra</p>
    <h1>${t("nav.more")}</h1>
    <div class="card" style="margin-top:14px;padding:6px 16px">
      <div class="setting"><div><strong>${t("appearance")}</strong><div class="faint">${state.theme === "dark" ? t("dark") : t("light")}</div></div>
        <div class="seg" style="width:150px"><button data-theme="dark" class="${state.theme === "dark" ? "on" : ""}">${t("dark")}</button><button data-theme="light" class="${state.theme === "light" ? "on" : ""}">${t("light")}</button></div>
      </div>
      <div class="setting"><div><strong>${t("currency")}</strong></div>
        <select class="selectish" id="cur">${Object.keys(RATES).map(c => `<option ${c === state.currency ? "selected" : ""}>${c}</option>`).join("")}</select>
      </div>
      <div class="setting"><div><strong>${t("language")}</strong></div>
        <select class="selectish" id="lang"><option value="en" ${state.lang === "en" ? "selected" : ""}>English</option><option value="no" ${state.lang === "no" ? "selected" : ""}>Norsk</option></select>
      </div>
    </div>
    <div class="section-head"><h2>${t("brand")}</h2></div>
    <div class="logo-grid">
      <div class="logo-tile dark"><img src="icons/icon-192.png" alt="Montra app icon" /></div>
      <div class="logo-tile light"><img src="icons/icon-512-light.png" alt="Montra light icon" /></div>
      <div class="logo-tile dark">${MARK}</div>
      <div class="logo-tile light"><img src="brand/mark-light.svg" alt="Montra monogram light" /></div>
    </div>
    <div class="card" style="margin-top:12px">
      <h3>${t("about")}</h3>
      <p class="muted">${t("aboutBody")}</p>
    </div>
  `;
  document.getElementById("cur").addEventListener("change", e => { state.currency = e.target.value; persist(); render(); });
  document.getElementById("lang").addEventListener("change", e => { state.lang = e.target.value; persist(); render(); });
}

function openSheet(html) {
  document.getElementById("sheet").innerHTML = `<div class="handle"></div>${html}`;
  document.getElementById("overlay").classList.add("show");
}
function closeSheet() { document.getElementById("overlay").classList.remove("show"); }
function toast(msg) {
  const el = document.getElementById("toast");
  el.textContent = msg;
  el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 1600);
}

document.getElementById("nav").addEventListener("click", e => {
  const btn = e.target.closest("button");
  if (!btn) return;
  document.querySelectorAll(".nav button").forEach(b => b.classList.remove("on"));
  btn.classList.add("on");
  document.querySelectorAll(".screen").forEach(s => s.classList.remove("active"));
  document.getElementById("screen-" + btn.dataset.tab).classList.add("active");
});
document.body.addEventListener("click", e => {
  const go = e.target.closest("[data-go]");
  if (go) document.querySelector(`.nav button[data-tab="${go.dataset.go}"]`).click();
  const theme = e.target.closest("[data-theme]");
  if (theme) { state.theme = theme.dataset.theme; persist(); render(); }
  const filter = e.target.closest("[data-filter]");
  if (filter) { state.filter = filter.dataset.filter; persist(); renderActivity(); }
  if (e.target.id === "overlay") closeSheet();
});
document.getElementById("addBtn").addEventListener("click", () => {
  openSheet(`
    <h2>${t("addTitle")}</h2>
    <div class="seg" id="kind" style="margin:12px 0">
      <button data-kind="purchase" class="on">${t("purchase")}</button>
      <button data-kind="income">${t("income")}</button>
      <button data-kind="wish">${t("wish")}</button>
      <button data-kind="goal">${t("goal")}</button>
    </div>
    <div class="field"><label>${t("name")}</label><input id="f-name" /></div>
    <div class="field"><label>${t("amount")}</label><input id="f-amt" inputmode="decimal" /></div>
    <div class="field"><label>${t("category")}</label><input id="f-cat" value="Daily" /></div>
    <button class="btn-accent btn-block" id="saveAdd">${t("save")}</button>
  `);
  let kind = "purchase";
  document.getElementById("kind").addEventListener("click", ev => {
    const b = ev.target.closest("button");
    if (!b) return;
    kind = b.dataset.kind;
    document.querySelectorAll("#kind button").forEach(x => x.classList.remove("on"));
    b.classList.add("on");
  });
  document.getElementById("saveAdd").addEventListener("click", () => {
    const name = document.getElementById("f-name").value.trim() || "Untitled";
    const amt = Math.abs(parseFloat(document.getElementById("f-amt").value) || 0) / RATES[state.currency];
    const cat = document.getElementById("f-cat").value.trim() || "General";
    if (kind === "purchase") state.txs.unshift({ id: Date.now(), name, cat, amount: -amt, day: "Today" });
    if (kind === "income") state.txs.unshift({ id: Date.now(), name, cat: "Income", amount: amt, day: "Today" });
    if (kind === "wish") state.wishes.unshift({ id: Date.now(), name, price: amt, saved: 0, priority: "Medium" });
    if (kind === "goal") state.goals.unshift({ id: Date.now(), name, target: amt, saved: 0, note: cat });
    persist();
    closeSheet();
    toast(t("confirm"));
    render();
  });
});

render();
setTimeout(() => document.getElementById("launch").classList.add("hide"), 700);
if ("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(() => {});
